This directory contains a number of examples that show how to use ordered
types to capture and maintain content order. The following list gives an
overview of each example:

element
  Shows how to use ordered types to capture and maintain element order,
  including element wildcards.

mixed
  Shows how to use ordered types to capture mixed content text and to
  maintain order information between elements and text.
